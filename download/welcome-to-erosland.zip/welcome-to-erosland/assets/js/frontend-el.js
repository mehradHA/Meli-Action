; (function ($) {
    "use strict";
    
    // Elementor hooks for frontend and editor
    $(window).on("elementor/frontend/init", () => {
        const moduleHandler = elementorModules.frontend.handlers.Base;

        // Swiper Slider
        const utcSwiperSlider = moduleHandler.extend({
            bindEvents: function bindEvents() {
                this.run();
            },
            run: function run() {
                const $addon = this.$element;
                let id = $addon.find('.ultimate-tag-cloud').attr('id');
                const $element = $addon.find('#' + id);

                if (!$element.find('.swiper').length) return;
                
                // Elementor breakpoints
                const el_breakpoints = elementorFrontend.config.responsive.activeBreakpoints || '';
                const breakpoints = {};
                for (let key in el_breakpoints) {
                    if (!el_breakpoints.hasOwnProperty(key)) continue;
                    const bp = el_breakpoints[key];
                    breakpoints[key] = bp.direction === 'max' ? bp.value : null;
                }
                const xl = breakpoints['laptop'] || 1366;
                const lg = breakpoints['tablet_extra'] || 1200;
                const md = breakpoints['tablet'] || 1024;
                const sm = breakpoints['mobile_extra'] || 880;
                const xs = breakpoints['mobile'] || 767;

                // Get Elementor settings
                const s = this.getElementSettings();

                // Responsive method
                function getResponsive(swiperSettings, key, defaultVal) {

                    const isValid = (v) => v !== undefined && v !== null && v !== '';

                    let xl  = isValid(swiperSettings[key]) ? swiperSettings[key] : defaultVal;
                    let lg  = isValid(swiperSettings[`${key}_laptop`]) ? swiperSettings[`${key}_laptop`] : xl;
                    let md  = isValid(swiperSettings[`${key}_tablet_extra`]) ? swiperSettings[`${key}_tablet_extra`] : lg;
                    let sm  = isValid(swiperSettings[`${key}_tablet`]) ? swiperSettings[`${key}_tablet`] : md;
                    let xs  = isValid(swiperSettings[`${key}_mobile_extra`]) ? swiperSettings[`${key}_mobile_extra`] : sm;
                    let xxs = isValid(swiperSettings[`${key}_mobile`]) ? swiperSettings[`${key}_mobile`] : xs;

                    return { xl, lg, md, sm, xs, xxs };
                }

                // Autoplay
                const autoplay = s.slider_autoplay === 'true' ? {
                    delay: parseInt(s.slider_interval || 3000),
                    disableOnInteraction: false,
                    pauseOnMouseEnter: s.slider_stop_on_hover === 'true',
                } : false;
                
                // Autoplay Progress Circle
                const progressCircle = $element.find(".autoplay-progress svg")[0];
                const progressContent = $element.find(".autoplay-progress span")[0];
                const swiperEvents = {};
                if (s.slide_item_circle_progress === 'true' && autoplay && progressCircle && progressContent) {
                    swiperEvents.autoplayTimeLeft = function (swiper, time, progress) {
                        progressCircle.style.setProperty("--progress", 1 - progress);
                        progressContent.textContent = `${Math.ceil(time / 1000)}s`;
                    };
                }
                
                // Pagination
                const hasDots = s.slider_dots === 'true';
                const bulletType = s.slider_bullet_type || 'bullets';
                const dynamicBullets = s.slider_dynamic_bullets === 'true';
                const decimalFraction = s.slider_decimal_fraction === 'yes';
                const hideTotalFraction = s.slider_current_fraction === 'yes';
                let pagination = false;

                if (hasDots) {
                    const paginationEl = $element.find('.swiper-pagination')[0];
                    pagination = {
                        el: paginationEl,
                        clickable: true,
                        dynamicBullets: dynamicBullets,
                        type: bulletType,
                        formatFractionCurrent: (num) => decimalFraction ? ('0' + num).slice(-2) : num,
                        formatFractionTotal: (num) => hideTotalFraction ? '' : (decimalFraction ? ('0' + num).slice(-2) : num),
                    };
                }

                // Navigation
                const hasNav = s.slider_nav === 'true';
                let navigation = false;
                if (hasNav) {
                    navigation = {
                        nextEl: $element.find('.swiper-button-next')[0],
                        prevEl: $element.find('.swiper-button-prev')[0],
                    };
                }

                // Scrollbar
                const hasScrollbar = s.slider_scrollbar === 'true';
                let scrollbar = false;
                if (hasScrollbar) {
                    scrollbar = {
                        el: $element.find('.swiper-scrollbar')[0],
                        hide: false,
                        draggable: true,
                    };
                }

                // Initialize Swiper
                const slidesPerView = getResponsive(s, 'sl_column', 3);
                const spaceBetween = getResponsive(s, 'sl_column_gap', 30);
                const slVertical = getResponsive(s, 'sl_vertical', 'horizontal');

                const swiperEl = $element.find('.swiper')[0];
                const swiper = new Swiper(swiperEl, {
                    direction: slVertical.xl,
                    speed: parseInt(s.slider_speed || 500),
                    loop: s.slider_loop === 'true',
                    freeMode: s.slider_free_mode === 'true',
                    autoHeight: s.slider_auto_height === 'true',
                    mousewheel: s.slider_mousewheel === 'true',
                    keyboard: s.slider_keyboard_control === 'true',
                    centeredSlides: s.slider_center_mode === 'true',
                    slidesPerView: slidesPerView.xl,
                    spaceBetween: spaceBetween.xl,
                    slidesPerGroup: parseInt(s.slides_to_scroll || 1),
                    grabCursor: s.slider_grab_cursor === 'true',
                    initialSlide: parseInt(s.slider_initial_slide || 0),
                    autoplay,
                    navigation,
                    pagination,
                    scrollbar,
                    on: swiperEvents,
                    breakpoints: {
                        0: { slidesPerView: slidesPerView.xxs, spaceBetween: spaceBetween.xxs, direction: slVertical.xxs },
                        [xs]: { slidesPerView: slidesPerView.xs, spaceBetween: spaceBetween.xs, direction: slVertical.xs },
                        [sm]: { slidesPerView: slidesPerView.sm, spaceBetween: spaceBetween.sm, direction: slVertical.sm },
                        [md]: { slidesPerView: slidesPerView.md, spaceBetween: spaceBetween.md, direction: slVertical.md },
                        [lg]: { slidesPerView: slidesPerView.lg, spaceBetween: spaceBetween.lg, direction: slVertical.lg },
                        [xl]: { slidesPerView: slidesPerView.xl, spaceBetween: spaceBetween.xl, direction: slVertical.xl },
                    },
                });
            }
        });

        ['ultimate_tag_cloud_el_widget.default'].forEach(widget => {
            elementorFrontend.hooks.addAction('frontend/element_ready/' + widget, function ($scope) {
                elementorFrontend.elementsHandler.addHandler(utcSwiperSlider, {
                    $element: $scope
                });
            });
        });
    });

})(jQuery);